Rachel Blacker
Web Science Systems Development
Spring 2016
Lab 4: Responsive App


When I first tried connecting my lab to the Twitter API, I got a PHP error. Upon talking with the TA and others, I added a line to the provided PHP file and it worked fine. 

For this lab I used the same styling as my lab1 and just converted it to angular. This was my first time ever using angular and I was very impressed with how easy it is to use and how powerful it can be. Additionally, my code became much cleaner than using plain javascript. 

Furthermore, when I added the search function, I put all of my javascript within a function that was called upon initial load and if anything was queried. I then realized that pressing enter did not work for searching, so I looked up what key value that was in order to call the search function when the key was pressed. 

For the @media property, I decided to only change the font size of my headers to make them smaller because the screen became smaller. 


Resources:
http://stackoverflow.com/questions/3642772/not-hacking-curlexception-60-curl-ssl-certificate-verification
