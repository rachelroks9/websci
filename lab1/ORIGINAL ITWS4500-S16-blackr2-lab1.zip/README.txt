Rachel Blacker
Web Science Systems Development
Spring 2016
Lab 1: HTML, CSS, JS, Bootstrap and JSON


When I first got the lab the first thing I did was learn about Bootstrap. While I have heard of Bootstrap, I did not know exactly how it worked. It was very interesting to see how it worked and once I got the hang of it, it became a very powerful tool. 

I then imported the JSON via a GET call. I set a variable URL so that you can easily change what JSON file you are importing data from. Pulling and splitting the data from the JSON file was very easy. When I put in the profile pictures I realized that there were a lot of broken images so I did some research and learned how to replace broken images with a default picture. 

What I found to be extremely challenging was handling the hashtags. Initially my check to see if the array was empty was not working. Once I finally figured that out, the rest of the lab went pretty smoothly. 

What is different about my ticker is that I change all of the tweets at once. For example I initially show 01234 and then after 3 seconds I show 56789. I used the JQuery slide down feature for this. This feature is also on my hashtags ticker, but I change the hashtags every 5 seconds. 

I found this lab to be very interesting. While it wasn’t too challenging, it required me to touch up on some topics and learn more about different things. I really enjoyed using Bootstrap and plan to use it in the future for my other projects. 

Resources:
http://stackoverflow.com/questions/92720/jquery-javascript-to-replace-broken-images
