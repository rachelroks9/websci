Make sure a mongoDb server is up and running. Otherwise the server won't wotk. Install all the dependencies using,
	>npm install
Then start the server using
	>node server.js